window.onload = function() {
  //<editor-fold desc="Changeable Configuration Block">
	const spec = {
  "openapi": "3.0.0",
  "info": {
    "title": "API Backend Documentation",
    "version": "0.1.0",
    "description": "Documentación para API de DenkiFi. Sistema de gestión de gimnasio. La API proporciona autenticación basada en JWT, y ofrece CRUD para los diferentes modulos del sistema.\n"
  },
  "servers": [
    {
      "url": "http://localhost:{port}",
      "description": "Servidor local",
      "variables": {
        "port": {
          "default": "5000"
        }
      }
    }
  ],
  "components": {
    "securitySchemes": {
      "cookieAuth": {
        "type": "apiKey",
        "in": "cookie",
        "name": "access_token"
      }
    },
    "schemas": {
      "User": {
        "type": "object",
        "properties": {
          "id_usuario": {
            "type": "string",
            "format": "uuid"
          },
          "activo": {
            "type": "integer",
            "default": 1
          },
          "username": {
            "type": "string",
            "minLength": 3,
            "maxLength": 20
          },
          "password": {
            "type": "string",
            "maxLength": 255
          },
          "id_tipo_rol": {
            "type": "integer",
            "minimum": 1,
            "maximum": 3,
            "default": 3
          },
          "nombres": {
            "type": "string",
            "minLength": 2,
            "maxLength": 50
          },
          "apellidos": {
            "type": "string",
            "minLength": 2,
            "maxLength": 50
          },
          "run": {
            "type": "string",
            "maxLength": 11,
            "nullable": true
          },
          "direccion": {
            "type": "string",
            "maxLength": 150,
            "nullable": true
          },
          "correo": {
            "type": "string",
            "format": "email",
            "maxLength": 100,
            "nullable": true
          },
          "genero": {
            "type": "integer",
            "minimum": 0,
            "maximum": 3,
            "default": 3
          },
          "fecha_nacimiento": {
            "type": "string",
            "format": "date",
            "nullable": true
          }
        }
      },
      "Plan": {
        "type": "object",
        "properties": {
          "id_plan": {
            "type": "integer"
          },
          "nombre": {
            "type": "string",
            "maxLength": 100
          },
          "activo": {
            "type": "boolean",
            "default": true
          },
          "clases_por_mes": {
            "type": "integer"
          },
          "valor_base": {
            "type": "integer"
          },
          "descripcion": {
            "type": "string",
            "maxLength": 250,
            "nullable": true
          }
        }
      }
    }
  },
  "security": [
    {
      "cookieAuth": []
    }
  ],
  "paths": {
    "/auth/login": {
      "post": {
        "summary": "Iniciar sesión",
        "description": "Inicia sesión para un usuario y genera un token JWT.",
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "username": {
                    "type": "string"
                  },
                  "password": {
                    "type": "string"
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Login exitoso con JWT.",
            "content": {
              "application/json": {
                "examples": {
                  "loginSuccess": {
                    "summary": "Ejemplo de respuesta exitosa",
                    "value": {
                      "id": "1744d576-17c4-492f-bcb4-cbb9483b8a71",
                      "username": "usuario1",
                      "token": "ey..."
                    }
                  }
                },
                "schema": {
                  "type": "object",
                  "properties": {
                    "id": {
                      "type": "string"
                    },
                    "username": {
                      "type": "string"
                    },
                    "token": {
                      "type": "string"
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "Contraseña incorrecta.",
            "content": {
              "application/json": {
                "examples": {
                  "unauthorized": {
                    "summary": "Ejemplo de respuesta no autorizada",
                    "value": {
                      "error": "Contraseña incorrecta"
                    }
                  }
                }
              }
            }
          },
          "404": {
            "description": "Usuario no encontrado.",
            "content": {
              "application/json": {
                "examples": {
                  "userNotFound": {
                    "summary": "Ejemplo de usuario no encontrado",
                    "value": {
                      "error": "Usuario no encontrado"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error interno del servidor.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error interno del servidor"
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/auth/logout": {
      "post": {
        "summary": "Cerrar sesión",
        "description": "Cierra la sesión del usuario actual.",
        "responses": {
          "200": {
            "description": "Logout exitoso.",
            "content": {
              "application/json": {
                "examples": {
                  "logoutSuccess": {
                    "summary": "Ejemplo de respuesta de logout",
                    "value": {
                      "message": "Logout exitoso"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error interno del servidor.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error interno del servidor"
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/auth/check": {
      "get": {
        "summary": "Verificar autenticación",
        "description": "Verifica si el usuario está autenticado usando el token almacenado en cookies.",
        "responses": {
          "200": {
            "description": "Usuario autenticado.",
            "content": {
              "application/json": {
                "examples": {
                  "authSuccess": {
                    "summary": "Ejemplo de respuesta de autenticación exitosa",
                    "value": {
                      "authenticated": true,
                      "user": {
                        "id": "1744d576-17c4-492f-bcb4-cbb9483b8a71",
                        "username": "usuario1"
                      }
                    }
                  }
                }
              }
            }
          },
          "401": {
            "description": "No autorizado, token inválido o ausente.",
            "content": {
              "application/json": {
                "examples": {
                  "unauthorized": {
                    "summary": "Ejemplo de respuesta no autorizada",
                    "value": {
                      "authenticated": false,
                      "error": "Token no valido o ausente"
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/users": {
      "get": {
        "summary": "Obtener usuarios",
        "description": "Obtiene la lista de todos los usuarios con paginación.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "limit",
            "in": "query",
            "schema": {
              "type": "integer",
              "default": 10
            }
          },
          {
            "name": "page",
            "in": "query",
            "schema": {
              "type": "integer",
              "default": 1
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Lista de usuarios obtenida.",
            "content": {
              "application/json": {
                "examples": {
                  "usersList": {
                    "summary": "Ejemplo de respuesta con lista de usuarios",
                    "value": {
                      "totalEntries": 20,
                      "totalPages": 10,
                      "currentPage": 1,
                      "limit": 2,
                      "users": [
                        {
                          "id_usuario": "1744d576-17c4-492f-bcb4-cbb9483b8a71",
                          "username": "usuario1",
                          "activo": 1,
                          "nombres": "Andres Gabriel",
                          "apellidos": "Peralta",
                          "run": "18247288-6"
                        },
                        {
                          "id_usuario": "1740d576-17c4-492f-bcb4-cba9483b8a71",
                          "username": "usuario2",
                          "activo": 1,
                          "nombres": "Paula Alejandra",
                          "apellidos": "Godoy Marquez",
                          "run": "19247288-6"
                        }
                      ]
                    }
                  }
                }
              }
            }
          },
          "400": {
            "description": "Parámetros de consulta no válidos.",
            "content": {
              "application/json": {
                "examples": {
                  "invalidParams": {
                    "summary": "Ejemplo de parámetros inválidos",
                    "value": {
                      "error": "Parámetros de consulta no válidos"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error al obtener la lista de usuarios.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error al obtener la lista de usuarios"
                    }
                  }
                }
              }
            }
          }
        }
      },
      "post": {
        "summary": "Crear usuario",
        "description": "Crea un nuevo usuario.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "id_usuario": {
                    "type": "string",
                    "format": "uuid"
                  },
                  "activo": {
                    "type": "integer",
                    "default": 1
                  },
                  "username": {
                    "type": "string",
                    "minLength": 3,
                    "maxLength": 20
                  },
                  "password": {
                    "type": "string",
                    "maxLength": 255
                  },
                  "id_tipo_rol": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 3,
                    "default": 3
                  },
                  "nombres": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 50
                  },
                  "apellidos": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 50
                  },
                  "run": {
                    "type": "string",
                    "maxLength": 11,
                    "nullable": true
                  },
                  "direccion": {
                    "type": "string",
                    "maxLength": 150,
                    "nullable": true
                  },
                  "correo": {
                    "type": "string",
                    "format": "email",
                    "maxLength": 100,
                    "nullable": true
                  },
                  "genero": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 3,
                    "default": 3
                  },
                  "fecha_nacimiento": {
                    "type": "string",
                    "format": "date",
                    "nullable": true
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Usuario creado exitosamente.",
            "content": {
              "application/json": {
                "examples": {
                  "userCreated": {
                    "summary": "Ejemplo de usuario creado",
                    "value": {
                      "id_usuario": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
                      "username": "aperalta"
                    }
                  }
                }
              }
            }
          },
          "400": {
            "description": "Datos no válidos.",
            "content": {
              "application/json": {
                "examples": {
                  "invalidData": {
                    "summary": "Ejemplo de datos no válidos",
                    "value": {
                      "error": "Los datos proporcionados no son válidos"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error al procesar la solicitud.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error al procesar la solicitud"
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/users/{id}": {
      "get": {
        "summary": "Obtener detalles del usuario",
        "description": "Obtiene los detalles de un usuario específico por su ID.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Detalles del usuario obtenidos.",
            "content": {
              "application/json": {
                "examples": {
                  "userDetails": {
                    "summary": "Ejemplo de detalles del usuario",
                    "value": {
                      "basic": {
                        "id_usuario": "9957b50b-376e-4003-947f-1c61fc056dbc",
                        "username": "acornejo",
                        "id_tipo_rol": 3,
                        "activo": 1,
                        "created_at": "2024-09-22T18:09:27.000Z",
                        "nombres": "Andres",
                        "apellidos": "Cornejo",
                        "run": "16888955-6",
                        "fecha_nacimiento": null,
                        "direccion": "",
                        "correo": "correoejemplo@gmail.com",
                        "genero": 1
                      },
                      "telefonos": [
                        {
                          "id_telefono": 2,
                          "id_tipo_telefono": 1,
                          "nombre_contacto": null,
                          "relacion": null,
                          "correo": null,
                          "numero": "56951344485"
                        }
                      ],
                      "redes": [
                        {
                          "id_red_social": 1,
                          "id_tipo_red": 1,
                          "handle": "arihel1251"
                        }
                      ]
                    }
                  }
                }
              }
            }
          },
          "404": {
            "description": "Usuario no encontrado.",
            "content": {
              "application/json": {
                "examples": {
                  "userNotFound": {
                    "summary": "Ejemplo de usuario no encontrado",
                    "value": {
                      "error": "Usuario no encontrado"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error inesperado al obtener los detalles del usuario.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error al obtener los detalles del usuario"
                    }
                  }
                }
              }
            }
          }
        }
      },
      "put": {
        "summary": "Actualizar usuario",
        "description": "Actualiza los detalles totales o parciales de un usuario especifico.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "examples": {
                "userUpdated": {
                  "summary": "Ejemplo de usuario actualizado",
                  "value": {
                    "id_usuario": "9957b50b-376e-4003-947f-1c61fc056dbc",
                    "username": "acornejo",
                    "id_tipo_rol": 3,
                    "activo": 1,
                    "created_at": "2024-09-22T21:09:27.000Z",
                    "nombres": "Andres a",
                    "apellidos": "cornejoo",
                    "run": "16888955-6",
                    "fecha_nacimiento": null,
                    "direccion": null,
                    "correo": null,
                    "genero": 1,
                    "redes": [
                      {
                        "id_red_social": 3,
                        "id_tipo_red": 1,
                        "handle": "ariheeleeeño"
                      },
                      {
                        "id_red_social": 4,
                        "id_tipo_red": 2,
                        "handle": "JOLINESsa"
                      }
                    ],
                    "telefonos": [
                      {
                        "id_telefono": 3,
                        "id_tipo_telefono": 1,
                        "nombre_contacto": null,
                        "relacion": null,
                        "correo": null,
                        "numero": "asdasdasdas"
                      },
                      {
                        "id_telefono": 4,
                        "id_tipo_telefono": 3,
                        "nombre_contacto": null,
                        "relacion": null,
                        "correo": null,
                        "numero": "15515695945"
                      }
                    ]
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Usuario actualizado correctamente.",
            "content": {
              "application/json": {
                "examples": {
                  "userUpdated": {
                    "summary": "Ejemplo de usuario actualizado",
                    "value": {
                      "basic": {
                        "id_usuario": "9957b50b-376e-4003-947f-1c61fc056dbc",
                        "username": "acornejo",
                        "id_tipo_rol": 3,
                        "activo": 1,
                        "created_at": "2024-09-22T18:09:27.000Z",
                        "nombres": "Andres",
                        "apellidos": "Cornejo",
                        "run": "16888955-6",
                        "fecha_nacimiento": null,
                        "direccion": "",
                        "correo": "correoejemplo@gmail.com",
                        "genero": 1
                      },
                      "telefonos": [
                        {
                          "id_telefono": 2,
                          "id_tipo_telefono": 1,
                          "nombre_contacto": null,
                          "relacion": null,
                          "correo": null,
                          "numero": "56951344485"
                        }
                      ],
                      "redes": [
                        {
                          "id_red_social": 1,
                          "id_tipo_red": 1,
                          "handle": "arihel1251"
                        }
                      ]
                    }
                  }
                }
              }
            }
          },
          "400": {
            "description": "Datos no válidos.",
            "content": {
              "application/json": {
                "examples": {
                  "invalidData": {
                    "summary": "Ejemplo de datos no válidos",
                    "value": {
                      "error": "Los datos proporcionados no son válidos"
                    }
                  }
                }
              }
            }
          },
          "404": {
            "description": "Usuario no encontrado.",
            "content": {
              "application/json": {
                "examples": {
                  "userNotFound": {
                    "summary": "Ejemplo de usuario no encontrado",
                    "value": {
                      "error": "Usuario no encontrado"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error al procesar la solicitud.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error al procesar la solicitud"
                    }
                  }
                }
              }
            }
          }
        }
      },
      "delete": {
        "summary": "Eliminar usuario",
        "description": "Elimina un usuario específico por su ID.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "string"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Usuario eliminado correctamente.",
            "content": {
              "application/json": {
                "examples": {
                  "userDeleted": {
                    "summary": "Ejemplo de usuario eliminado",
                    "value": {
                      "message": "Usuario eliminado exitosamente"
                    }
                  }
                }
              }
            }
          },
          "404": {
            "description": "Usuario no encontrado.",
            "content": {
              "application/json": {
                "examples": {
                  "userNotFound": {
                    "summary": "Ejemplo de usuario no encontrado",
                    "value": {
                      "error": "Usuario no encontrado"
                    }
                  }
                }
              }
            }
          },
          "500": {
            "description": "Error al procesar la solicitud.",
            "content": {
              "application/json": {
                "examples": {
                  "serverError": {
                    "summary": "Ejemplo de error interno",
                    "value": {
                      "error": "Error al procesar la solicitud"
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/planes": {
      "get": {
        "summary": "Obtener todos los planes",
        "description": "Obtiene la lista de todos los planes disponibles.",
        "responses": {
          "200": {
            "description": "Lista de planes obtenida.",
            "content": {
              "application/json": {
                "examples": {
                  "plansList": {
                    "summary": "Ejemplo de lista de planes",
                    "value": [
                      {
                        "id_plan": 1,
                        "nombre": "12CL (2024)",
                        "clases_por_mes": 12,
                        "valor_base": 15000,
                        "descripcion": "Plan del periodo 2024"
                      }
                    ]
                  }
                }
              }
            }
          }
        }
      },
      "post": {
        "summary": "Crear nuevo plan",
        "description": "Crea un nuevo plan con los detalles proporcionados.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "id_plan": {
                    "type": "integer"
                  },
                  "nombre": {
                    "type": "string",
                    "maxLength": 100
                  },
                  "activo": {
                    "type": "boolean",
                    "default": true
                  },
                  "clases_por_mes": {
                    "type": "integer"
                  },
                  "valor_base": {
                    "type": "integer"
                  },
                  "descripcion": {
                    "type": "string",
                    "maxLength": 250,
                    "nullable": true
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Plan creado exitosamente.",
            "content": {
              "application/json": {
                "examples": {
                  "planCreated": {
                    "summary": "Ejemplo de plan creado",
                    "value": {
                      "id_plan": 2,
                      "nombre": "MES (2023)",
                      "clases_por_mes": 0,
                      "valor_base": 50000
                    }
                  }
                }
              }
            }
          }
        }
      },
      "put": {
        "summary": "Actualizar un plan existente",
        "description": "Actualiza los detalles de un plan específico.",
        "security": [
          {
            "cookieAuth": []
          }
        ],
        "requestBody": {
          "required": true,
          "content": {
            "application/json": {
              "schema": {
                "type": "object",
                "properties": {
                  "id_plan": {
                    "type": "integer"
                  },
                  "nombre": {
                    "type": "string",
                    "maxLength": 100
                  },
                  "activo": {
                    "type": "boolean",
                    "default": true
                  },
                  "clases_por_mes": {
                    "type": "integer"
                  },
                  "valor_base": {
                    "type": "integer"
                  },
                  "descripcion": {
                    "type": "string",
                    "maxLength": 250,
                    "nullable": true
                  }
                }
              }
            }
          }
        },
        "responses": {
          "200": {
            "description": "Plan actualizado correctamente.",
            "content": {
              "application/json": {
                "examples": {
                  "planUpdated": {
                    "summary": "Ejemplo de plan actualizado",
                    "value": {
                      "id_plan": 2,
                      "nombre": "12CL (2023)",
                      "clases_por_mes": 12,
                      "valor_base": 35000
                    }
                  }
                }
              }
            }
          }
        }
      }
    },
    "/planes/{id}": {
      "get": {
        "summary": "Obtener plan por ID",
        "description": "Obtiene un plan específico por su ID.",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "required": true,
            "schema": {
              "type": "integer"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "Detalles del plan obtenidos.",
            "content": {
              "application/json": {
                "examples": {
                  "planDetails": {
                    "summary": "Ejemplo de detalles del plan",
                    "value": {
                      "id_plan": 1,
                      "nombre": "Plan Básico",
                      "clases_por_mes": 10,
                      "valor_base": 15000,
                      "descripcion": "Plan adecuado para principiantes"
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
  // the following lines will be replaced by docker/configurator, when it runs in a docker-container
window.ui = SwaggerUIBundle({
    spec: spec,
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [
      SwaggerUIBundle.presets.apis,
      SwaggerUIStandalonePreset
    ],
    plugins: [
      SwaggerUIBundle.plugins.DownloadUrl
    ],
    layout: "StandaloneLayout"
  });

  //</editor-fold>
};